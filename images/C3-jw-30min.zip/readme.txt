Link to Original Images:
https://data.broadinstitute.org/bbbc/BBBC020/

Citation:
We used a subset of images from the image set BBBC020 from the Broad Bioimage Benchmark Collection [Ljosa et al., Nature Methods, 2012].

Copyright:
The BBBC020 images and ground truth are licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License by Roland Lang.
